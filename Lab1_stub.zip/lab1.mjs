export const questionOne = (arr) => {
  // Implement question 1 here
  return; //return result
};

export const questionTwo = (index, multiplier) => {
  // Implement question 2 here
  return; //return result
};

export const questionThree = (str) => {
  // Implement question 3 here
  return; //return result
};

export const questionFour = (arr) => {
  // Implement question 4 here
  return; //return result
};

//DO NOT FORGET TO UPDATE THE INFORMATION BELOW OR IT WILL BE -2 POINTS PER FIELD THAT IS MISSING OR NOT CHANGED.
export const studentInfo = {
  firstName: 'YOUR FIRST NAME',
  lastName: 'YOUR LAST NAME',
  studentId: 'YOUR STUDENT ID'
};
